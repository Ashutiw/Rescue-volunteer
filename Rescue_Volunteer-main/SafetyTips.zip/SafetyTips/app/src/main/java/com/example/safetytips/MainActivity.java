package com.example.safetytips;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

        TextView textview;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);


        Button turnado1 = findViewById (R.id.turnado);
        Button hurricane1 = findViewById (R.id.hurricane);
        Button thunderstorm1 = findViewById (R.id.thunderstorm);
        Button drought1 = findViewById (R.id.drought);
        Button winterstorm1 = findViewById (R.id.winterstorm);
        Button earthquake1 = findViewById (R.id.earthquake);
        Button flood1 = findViewById (R.id.flood);
        Button cyclone1 = findViewById (R.id.cyclone);
        Button tsunami1 = findViewById (R.id.tsunami);
        Button volcanoes1 = findViewById (R.id.volcanoes);
        Button corona1 = findViewById (R.id.corona);

turnado1.setOnClickListener (this);
        hurricane1.setOnClickListener (this);
        thunderstorm1 .setOnClickListener (this);
        drought1.setOnClickListener (this);
        winterstorm1.setOnClickListener (this);
        earthquake1.setOnClickListener (this);
        flood1.setOnClickListener (this);
        cyclone1.setOnClickListener (this);
        tsunami1.setOnClickListener (this);
        volcanoes1.setOnClickListener (this);
        corona1.setOnClickListener (this);

        }


public void onClick(View v) {
   // Button turnado1 = findViewById (R.id.turnado);
        switch(v.getId ()){

        case R.id.turnado:
Intent intent=new Intent ( MainActivity.this,turnadotips.class );
                startActivity (intent);
        break;
        case R.id.hurricane:
            Intent intent1 =new Intent ( MainActivity.this,hurricanetips.class );
            startActivity (intent1);
        break;
        case R.id.thunderstorm:

            Intent intent2=new Intent ( MainActivity.this,thunderstormtips.class );
            startActivity (intent2);
        break;
        case R.id.drought:
            Intent intent3=new Intent ( MainActivity.this,droughttips.class );
            startActivity (intent3);

        break;
        case R.id.winterstorm:

            Intent intent4=new Intent ( MainActivity.this,winterstormtips.class );
            startActivity (intent4);

        break;
        case R.id.earthquake:


            Intent intent5=new Intent ( MainActivity.this,earthquaketips.class );
            startActivity (intent5);
        break;
        case R.id.flood:

            Intent intent6=new Intent ( MainActivity.this,floodtips.class );
            startActivity (intent6);

        break;
        case R.id.cyclone:

            Intent intent7=new Intent ( MainActivity.this,cyclonetips.class );
            startActivity (intent7);
        break;
        case R.id.tsunami:

            Intent intent8=new Intent ( MainActivity.this,tsunamitips.class );
            startActivity (intent8);
        break;
        case R.id.volcanoes:

            Intent intent9=new Intent ( MainActivity.this,volcanoestips.class );
            startActivity (intent9);
        break;
        case R.id.corona:
            Intent intent10=new Intent ( MainActivity.this,coronatips.class );
            startActivity (intent10);
        break;
        }
        }

}